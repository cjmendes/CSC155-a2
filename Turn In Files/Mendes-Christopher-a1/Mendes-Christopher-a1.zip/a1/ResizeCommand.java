package a1;

import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;

public class ResizeCommand{

	
}
